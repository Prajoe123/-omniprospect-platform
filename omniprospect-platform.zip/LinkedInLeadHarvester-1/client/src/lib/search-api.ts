import { apiRequest } from "./queryClient";

export interface SearchFilters {
  location?: string;
  company_size?: string;
  industry?: string;
  job_title?: string;
}

export interface SearchQuery {
  query: string;
  source: "google" | "bing" | "serpapi" | "all";
  filters?: SearchFilters;
  limit?: number;
}

export interface SearchResult {
  id: number;
  results: Array<{
    source: string;
    results: any[];
    totalResults: number;
    searchTime: number;
  }>;
  errors: Array<{
    source: string;
    error: string;
  }>;
  query: string;
  totalSources: number;
}

export async function performSearch(searchQuery: SearchQuery): Promise<SearchResult> {
  const response = await apiRequest("POST", "/api/search", searchQuery);
  return response.json();
}

export async function getSearchHistory(limit = 50): Promise<any[]> {
  const response = await apiRequest("GET", `/api/search/history?limit=${limit}`);
  return response.json();
}

export async function getDashboardStats(): Promise<any> {
  const response = await apiRequest("GET", "/api/dashboard/stats");
  return response.json();
}

export async function getPlatformConnections(): Promise<any[]> {
  const response = await apiRequest("GET", "/api/platforms");
  return response.json();
}

export async function getApiUsageAnalytics(days = 30): Promise<any[]> {
  const response = await apiRequest("GET", `/api/analytics/usage?days=${days}`);
  return response.json();
}

export async function getProspects(limit = 50): Promise<any[]> {
  const response = await apiRequest("GET", `/api/prospects?limit=${limit}`);
  return response.json();
}

export async function createProspect(prospectData: any): Promise<any> {
  const response = await apiRequest("POST", "/api/prospects", prospectData);
  return response.json();
}

export async function getWorkflows(): Promise<any[]> {
  const response = await apiRequest("GET", "/api/workflows");
  return response.json();
}

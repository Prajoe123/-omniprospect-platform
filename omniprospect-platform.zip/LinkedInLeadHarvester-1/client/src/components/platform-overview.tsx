import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import StatsCard from "@/components/ui/stats-card";
import {
  Users,
  Workflow,
  Network,
  TrendingUp,
  UserPlus,
  Send,
  Bot,
  RotateCcw,
  Linkedin,
} from "lucide-react";

interface PlatformOverviewProps {
  stats: any;
  platforms: any[];
  isLoading: boolean;
}

export default function PlatformOverview({ stats, platforms, isLoading }: PlatformOverviewProps) {
  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case "linkedin":
        return <Linkedin className="h-4 w-4 text-blue-600" />;
      case "google":
        return <Network className="h-4 w-4 text-blue-500" />;
      case "bing":
        return <Network className="h-4 w-4 text-indigo-600" />;
      case "yahoo":
        return <Network className="h-4 w-4 text-purple-600" />;
      default:
        return <Network className="h-4 w-4 text-gray-500" />;
    }
  };

  const getTimeSince = (date: string | Date) => {
    const now = new Date();
    const then = new Date(date);
    const diffMs = now.getTime() - then.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins} min ago`;
    if (diffMins < 1440) return `${Math.floor(diffMins / 60)} hour ago`;
    return `${Math.floor(diffMins / 1440)} days ago`;
  };

  const activities = [
    {
      icon: <UserPlus className="h-4 w-4 text-blue-600" />,
      description: "Added 47 new prospects from LinkedIn search",
      time: "2 minutes ago",
    },
    {
      icon: <Send className="h-4 w-4 text-green-600" />,
      description: 'Outreach campaign "Q1 2025" completed',
      time: "1 hour ago",
    },
    {
      icon: <Bot className="h-4 w-4 text-purple-600" />,
      description: "AI enhanced 156 prospect profiles",
      time: "3 hours ago",
    },
    {
      icon: <RotateCcw className="h-4 w-4 text-orange-600" />,
      description: 'Workflow "LinkedIn→CRM" executed',
      time: "5 hours ago",
    },
  ];

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-8">
      {/* Platform Statistics */}
      <div className="xl:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Platform Overview</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  {[...Array(4)].map((_, i) => (
                    <Skeleton key={i} className="h-20" />
                  ))}
                </div>
                <div className="space-y-3">
                  {[...Array(3)].map((_, i) => (
                    <Skeleton key={i} className="h-16" />
                  ))}
                </div>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                  <StatsCard
                    title="Total Prospects"
                    value={stats?.prospects?.total?.toLocaleString() || "12,847"}
                    icon={<Users className="h-5 w-5" />}
                    gradient="from-blue-50 to-blue-100"
                    iconColor="text-primary"
                  />
                  <StatsCard
                    title="Active Workflows"
                    value={stats?.workflows?.active?.toString() || "23"}
                    icon={<Workflow className="h-5 w-5" />}
                    gradient="from-green-50 to-green-100"
                    iconColor="text-success"
                  />
                  <StatsCard
                    title="Platforms"
                    value={stats?.platforms?.connected?.toString() || "7"}
                    icon={<Network className="h-5 w-5" />}
                    gradient="from-purple-50 to-purple-100"
                    iconColor="text-purple-600"
                  />
                  <StatsCard
                    title="Conversion Rate"
                    value={stats?.prospects?.conversionRate || "18.3%"}
                    icon={<TrendingUp className="h-5 w-5" />}
                    gradient="from-orange-50 to-orange-100"
                    iconColor="text-warning"
                  />
                </div>

                {/* Platform Integration Status */}
                <div className="space-y-3">
                  <h4 className="font-medium text-foreground">Connected Platforms</h4>
                  {platforms?.length > 0 ? (
                    platforms.map((platform, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 bg-background-secondary rounded-lg"
                      >
                        <div className="flex items-center gap-3">
                          {getPlatformIcon(platform.platform)}
                          <span className="font-medium capitalize">{platform.platform}</span>
                          <Badge
                            variant={platform.status === "connected" ? "default" : "secondary"}
                            className={
                              platform.status === "connected"
                                ? "bg-green-100 text-green-800 hover:bg-green-100"
                                : ""
                            }
                          >
                            {platform.status}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Last sync: {platform.lastSync ? getTimeSince(platform.lastSync) : "Never"}
                        </div>
                      </div>
                    ))
                  ) : (
                    <>
                      <div className="flex items-center justify-between p-3 bg-background-secondary rounded-lg">
                        <div className="flex items-center gap-3">
                          <Linkedin className="h-4 w-4 text-blue-600" />
                          <span className="font-medium">LinkedIn (Public Profiles)</span>
                          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                            Connected
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">Last sync: 2 min ago</div>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-background-secondary rounded-lg">
                        <div className="flex items-center gap-3">
                          <Network className="h-4 w-4 text-blue-500" />
                          <span className="font-medium">Google Custom Search</span>
                          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                            Connected
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">Last sync: 5 min ago</div>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-background-secondary rounded-lg">
                        <div className="flex items-center gap-3">
                          <Network className="h-4 w-4 text-indigo-600" />
                          <span className="font-medium">Bing Web Search</span>
                          <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                            Connected
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">Last sync: 10 min ago</div>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-background-secondary rounded-lg">
                        <div className="flex items-center gap-3">
                          <Network className="h-4 w-4 text-purple-600" />
                          <span className="font-medium">Yahoo Search</span>
                          <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
                            Setup Required
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">Not configured</div>
                      </div>
                    </>
                  )}
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {activities.map((activity, index) => (
              <div key={index} className="flex items-start gap-3">
                <div className="w-8 h-8 bg-background-secondary rounded-full flex items-center justify-center flex-shrink-0">
                  {activity.icon}
                </div>
                <div>
                  <p className="text-sm text-foreground">{activity.description}</p>
                  <p className="text-xs text-muted-foreground">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>

          <Button variant="ghost" className="w-full mt-4">
            View All Activity
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

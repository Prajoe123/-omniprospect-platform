import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Linkedin, 
  Network,
  Info,
  ExternalLink,
  BarChart3,
  TrendingUp,
  Users
} from "lucide-react";
import ComplianceMonitor from "./compliance-monitor";
import UsageWarnings from "./usage-warnings";

interface ComplianceDashboardProps {
  className?: string;
}

export default function ComplianceDashboard({ className }: ComplianceDashboardProps) {
  // Mock compliance data - in real app this would come from API
  const complianceData = {
    linkedin: {
      dailyUsed: 23,
      dailyLimit: 100,
      accountType: "free" as const,
      lastRequest: "2 minutes ago",
      rateLimit: 3
    },
    google: {
      dailyUsed: 92,
      dailyLimit: 100,
      monthlyUsed: 2150,
      monthlyLimit: 3000,
      apiKeyConfigured: true
    },
    bing: {
      dailyUsed: 15,
      dailyLimit: 33,
      monthlyUsed: 450,
      monthlyLimit: 1000,
      apiKeyConfigured: true
    },
    yahoo: {
      dailyUsed: 8,
      estimatedLimit: 200,
      avgRequestTime: 850,
      robotsTxtCompliant: true
    }
  };

  const handleRefreshCompliance = () => {
    // Refresh compliance data
    console.log("Refreshing compliance data...");
  };

  const handleViewGuide = (platform: string) => {
    // Navigate to platform-specific compliance guide
    console.log(`Viewing ${platform} compliance guide`);
  };

  return (
    <div className={`space-y-6 ${className}`}>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Compliance Dashboard</h1>
          <p className="text-muted-foreground">
            Monitor usage limits and maintain compliance across all platforms
          </p>
        </div>
        <Button onClick={handleRefreshCompliance}>
          <Clock className="h-4 w-4 mr-2" />
          Refresh Data
        </Button>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="linkedin">LinkedIn</TabsTrigger>
          <TabsTrigger value="search-apis">Search APIs</TabsTrigger>
          <TabsTrigger value="guidelines">Guidelines</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Overall Compliance Score */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Compliance Score</CardTitle>
                <Shield className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">98%</div>
                <p className="text-xs text-muted-foreground">
                  Excellent compliance across all platforms
                </p>
                <Progress value={98} className="mt-2 h-2" />
              </CardContent>
            </Card>

            {/* Daily Searches */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Searches Today</CardTitle>
                <BarChart3 className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">138</div>
                <p className="text-xs text-muted-foreground">
                  +12% from yesterday
                </p>
                <div className="mt-2 flex items-center text-xs text-green-600">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  Within all limits
                </div>
              </CardContent>
            </Card>

            {/* Active Platforms */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Platforms</CardTitle>
                <Users className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">4/4</div>
                <p className="text-xs text-muted-foreground">
                  All sources connected
                </p>
                <div className="mt-2 flex gap-1">
                  <Badge variant="outline" className="text-xs">LinkedIn</Badge>
                  <Badge variant="outline" className="text-xs">Google</Badge>
                  <Badge variant="outline" className="text-xs">Bing</Badge>
                  <Badge variant="outline" className="text-xs">Yahoo</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          <ComplianceMonitor data={complianceData} onRefresh={handleRefreshCompliance} />
        </TabsContent>

        <TabsContent value="linkedin" className="space-y-6">
          <UsageWarnings 
            platform="linkedin" 
            usageData={{
              used: complianceData.linkedin.dailyUsed,
              limit: complianceData.linkedin.dailyLimit,
              percentage: (complianceData.linkedin.dailyUsed / complianceData.linkedin.dailyLimit) * 100
            }}
            onViewCompliance={() => handleViewGuide("linkedin")}
          />

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Linkedin className="h-5 w-5 text-blue-600" />
                LinkedIn Detailed Metrics
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="text-sm font-medium">Daily Profile Views</div>
                  <div className="text-2xl font-bold">{complianceData.linkedin.dailyUsed}</div>
                  <Progress value={(complianceData.linkedin.dailyUsed / complianceData.linkedin.dailyLimit) * 100} />
                  <div className="text-xs text-muted-foreground">
                    {complianceData.linkedin.dailyLimit - complianceData.linkedin.dailyUsed} remaining today
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="text-sm font-medium">Request Rate</div>
                  <div className="text-2xl font-bold">{complianceData.linkedin.rateLimit}s</div>
                  <div className="text-xs text-muted-foreground">
                    Delay between requests (compliant)
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="search-apis" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Google Custom Search */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Network className="h-4 w-4 text-blue-500" />
                  Google Custom Search
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Daily Usage</span>
                    <span className="font-medium">{complianceData.google.dailyUsed}/100</span>
                  </div>
                  <Progress value={(complianceData.google.dailyUsed / complianceData.google.dailyLimit) * 100} />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Monthly Usage</span>
                    <span className="font-medium">{complianceData.google.monthlyUsed}/{complianceData.google.monthlyLimit}</span>
                  </div>
                  <Progress value={(complianceData.google.monthlyUsed / complianceData.google.monthlyLimit) * 100} />
                </div>
                <Alert className="border-green-200 bg-green-50">
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertDescription className="text-sm">
                    Official API - Fully compliant with Google's terms
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>

            {/* Bing Web Search */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  <Network className="h-4 w-4 text-indigo-600" />
                  Bing Web Search
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Monthly Usage</span>
                    <span className="font-medium">{complianceData.bing.monthlyUsed}/{complianceData.bing.monthlyLimit}</span>
                  </div>
                  <Progress value={(complianceData.bing.monthlyUsed / complianceData.bing.monthlyLimit) * 100} />
                  <div className="text-xs text-muted-foreground">
                    Daily equivalent: ~{Math.round(complianceData.bing.monthlyLimit / 30)} queries
                  </div>
                </div>
                <Alert className="border-green-200 bg-green-50">
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertDescription className="text-sm">
                    Microsoft Azure API - Fully compliant
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </div>

          <UsageWarnings 
            platform="google"
            usageData={{
              used: complianceData.google.dailyUsed,
              limit: complianceData.google.dailyLimit,
              percentage: (complianceData.google.dailyUsed / complianceData.google.dailyLimit) * 100
            }}
            onViewCompliance={() => handleViewGuide("google")}
          />
        </TabsContent>

        <TabsContent value="guidelines" className="space-y-6">
          <UsageWarnings platform="all" onViewCompliance={() => handleViewGuide("all")} />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Platform Limits Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">LinkedIn (Free)</span>
                    <Badge variant="outline">100 profiles/day</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Google Custom Search</span>
                    <Badge variant="outline">100 queries/day</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Bing Web Search</span>
                    <Badge variant="outline">1,000 queries/month</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Yahoo Search</span>
                    <Badge variant="outline">Rate limited</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-base">Compliance Resources</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <ExternalLink className="h-3 w-3 mr-2" />
                  LinkedIn User Agreement
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <ExternalLink className="h-3 w-3 mr-2" />
                  Google API Terms
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <ExternalLink className="h-3 w-3 mr-2" />
                  Microsoft Azure Terms
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start">
                  <Info className="h-3 w-3 mr-2" />
                  Best Practices Guide
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
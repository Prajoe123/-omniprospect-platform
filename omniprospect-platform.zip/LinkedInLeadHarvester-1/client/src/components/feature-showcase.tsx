import { Card, CardContent } from "@/components/ui/card";
import { Brain, Network, Shield, CheckCircle2, Users, BarChart3, Code, Database, Linkedin } from "lucide-react";

export default function FeatureShowcase() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
      {/* AI-Powered Intelligence */}
      <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 border-purple-100">
        <CardContent className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl flex items-center justify-center">
              <Brain className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">AI-Powered Intelligence</h3>
              <p className="text-sm text-muted-foreground">OpenAI GPT-4o Integration</p>
            </div>
          </div>
          <ul className="space-y-2 text-sm text-foreground">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-success" />
              Contact enrichment & validation
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-success" />
              Personalized outreach generation
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-success" />
              Industry classification (ML)
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-success" />
              Profile enhancement (NLP)
            </li>
          </ul>
        </CardContent>
      </Card>

      {/* Search Engine Integration */}
      <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-100">
        <CardContent className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-xl flex items-center justify-center">
              <Network className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">Multi-Source Search</h3>
              <p className="text-sm text-muted-foreground">Google, Bing, Yahoo & LinkedIn</p>
            </div>
          </div>
          <div className="grid grid-cols-4 gap-2 mb-3">
            <div className="text-center p-2 bg-surface rounded-lg">
              <Network className="h-5 w-5 text-blue-500 mx-auto" />
            </div>
            <div className="text-center p-2 bg-surface rounded-lg">
              <Network className="h-5 w-5 text-indigo-600 mx-auto" />
            </div>
            <div className="text-center p-2 bg-surface rounded-lg">
              <Network className="h-5 w-5 text-purple-600 mx-auto" />
            </div>
            <div className="text-center p-2 bg-surface rounded-lg">
              <Linkedin className="h-5 w-5 text-blue-600 mx-auto" />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            Compliant web scraping with robots.txt respect and rate limiting
          </p>
        </CardContent>
      </Card>

      {/* Enterprise Features */}
      <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-100">
        <CardContent className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
              <Shield className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground">Enterprise Grade</h3>
              <p className="text-sm text-muted-foreground">Production-ready architecture</p>
            </div>
          </div>
          <ul className="space-y-2 text-sm text-foreground">
            <li className="flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" />
              Multi-user management
            </li>
            <li className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4 text-primary" />
              Advanced analytics dashboard
            </li>
            <li className="flex items-center gap-2">
              <Code className="h-4 w-4 text-primary" />
              Complete API ecosystem
            </li>
            <li className="flex items-center gap-2">
              <Database className="h-4 w-4 text-primary" />
              PostgreSQL + Gunicorn
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

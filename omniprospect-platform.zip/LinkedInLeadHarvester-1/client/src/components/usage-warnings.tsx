import { Alert, AlertDescription } from "@/components/ui/alert";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  AlertTriangle, 
  Shield, 
  Clock, 
  ExternalLink,
  Info,
  AlertCircle,
  CheckCircle2
} from "lucide-react";

interface UsageWarningsProps {
  platform: "linkedin" | "google" | "bing" | "yahoo" | "all";
  usageData?: {
    used: number;
    limit: number;
    percentage: number;
  };
  onDismiss?: () => void;
  onViewCompliance?: () => void;
}

export default function UsageWarnings({ platform, usageData, onDismiss, onViewCompliance }: UsageWarningsProps) {
  const getWarningLevel = (percentage: number) => {
    if (percentage >= 95) return "critical";
    if (percentage >= 85) return "warning";
    if (percentage >= 70) return "caution";
    return "safe";
  };

  const warningLevel = usageData ? getWarningLevel(usageData.percentage) : "safe";

  const platformWarnings = {
    linkedin: {
      critical: {
        title: "LinkedIn Daily Limit Nearly Reached",
        description: "You've used 95%+ of your daily LinkedIn limit. Further searches may be blocked.",
        actions: ["Stop searching until tomorrow", "Upgrade to Premium account", "Review usage patterns"]
      },
      warning: {
        title: "LinkedIn Usage High",
        description: "You've used 85%+ of your daily limit. Consider slowing down to avoid hitting the limit.",
        actions: ["Space out remaining searches", "Monitor usage closely", "Plan tomorrow's searches"]
      },
      caution: {
        title: "LinkedIn Usage Reminder",
        description: "You've used 70% of your daily limit. Remember to stay compliant with LinkedIn's terms.",
        actions: ["Monitor remaining quota", "Ensure 2-3 second delays", "Review compliance guidelines"]
      }
    },
    google: {
      critical: {
        title: "Google API Limit Nearly Reached",
        description: "You've used 95%+ of your daily Google Custom Search quota.",
        actions: ["Pause Google searches", "Consider upgrading to paid tier", "Use alternative sources"]
      },
      warning: {
        title: "Google API Usage High",
        description: "You've used 85%+ of your daily Google quota. Additional queries will incur charges.",
        actions: ["Monitor remaining quota", "Consider paid tier", "Use Bing for additional searches"]
      }
    },
    bing: {
      warning: {
        title: "Bing API Usage High",
        description: "You've used a significant portion of your monthly Bing quota.",
        actions: ["Monitor monthly usage", "Consider upgrading tier", "Use Google for priority searches"]
      }
    },
    yahoo: {
      warning: {
        title: "Yahoo Request Rate High",
        description: "High volume of Yahoo requests detected. Ensure compliance with rate limiting.",
        actions: ["Increase delays between requests", "Monitor for access blocks", "Use as supplementary source"]
      }
    }
  };

  const complianceGuidelines = {
    linkedin: [
      "Only scrape publicly available profile information",
      "Maintain 2-3 second delays between profile requests",
      "Stay under 100 profiles per day for free accounts",
      "Never scrape private messages or personal data",
      "Respect LinkedIn's robots.txt and terms of service"
    ],
    google: [
      "Use Google's official Custom Search API only",
      "Respect daily quotas (100 free, then $5/1000 queries)",
      "Don't scrape Google search results directly",
      "Follow Google's API usage policies",
      "Monitor costs if using paid tier"
    ],
    bing: [
      "Use Microsoft's official Bing Web Search API",
      "Stay within your Azure subscription limits",
      "Monitor monthly usage quotas",
      "Follow Microsoft's API terms of service",
      "Consider upgrading tiers for higher volumes"
    ],
    yahoo: [
      "Respect robots.txt directives automatically",
      "Maintain 1-2 requests per second maximum",
      "Use as supplementary search source only",
      "Monitor for rate limiting responses",
      "Implement proper error handling"
    ]
  };

  const renderPlatformWarning = () => {
    if (!usageData || warningLevel === "safe") return null;

    const warning = platformWarnings[platform]?.[warningLevel];
    if (!warning) return null;

    const alertVariant = warningLevel === "critical" ? "destructive" : "default";
    const iconColor = warningLevel === "critical" ? "text-red-500" : 
                     warningLevel === "warning" ? "text-yellow-500" : "text-orange-500";

    return (
      <Alert variant={alertVariant} className="mb-4">
        <AlertTriangle className={`h-4 w-4 ${iconColor}`} />
        <AlertDescription>
          <div className="space-y-3">
            <div>
              <div className="font-medium">{warning.title}</div>
              <div className="text-sm mt-1">{warning.description}</div>
              {usageData && (
                <div className="text-sm mt-2 opacity-75">
                  Current usage: {usageData.used} / {usageData.limit} ({usageData.percentage}%)
                </div>
              )}
            </div>
            
            <div className="space-y-1">
              <div className="text-sm font-medium">Recommended Actions:</div>
              <ul className="text-sm space-y-0.5">
                {warning.actions.map((action, index) => (
                  <li key={index} className="flex items-start gap-1">
                    <span className="text-xs mt-0.5">•</span>
                    <span>{action}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={onViewCompliance}>
                <Shield className="h-3 w-3 mr-1" />
                View Compliance
              </Button>
              {onDismiss && (
                <Button size="sm" variant="ghost" onClick={onDismiss}>
                  Dismiss
                </Button>
              )}
            </div>
          </div>
        </AlertDescription>
      </Alert>
    );
  };

  const renderComplianceGuidelines = () => {
    const guidelines = platform === "all" 
      ? Object.entries(complianceGuidelines).flat()
      : complianceGuidelines[platform] || [];

    if (guidelines.length === 0) return null;

    return (
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Shield className="h-4 w-4 text-blue-600" />
            <span className="font-medium text-blue-900">
              {platform === "all" ? "General" : platform.charAt(0).toUpperCase() + platform.slice(1)} Compliance Guidelines
            </span>
          </div>
          
          {platform === "all" ? (
            <div className="grid md:grid-cols-2 gap-4">
              {Object.entries(complianceGuidelines).map(([platformName, rules]) => (
                <div key={platformName} className="space-y-2">
                  <div className="font-medium text-sm text-blue-800 capitalize">
                    {platformName} Guidelines:
                  </div>
                  <ul className="text-sm text-blue-700 space-y-1">
                    {rules.slice(0, 3).map((rule, index) => (
                      <li key={index} className="flex items-start gap-1">
                        <CheckCircle2 className="h-3 w-3 mt-0.5 text-green-600 flex-shrink-0" />
                        <span>{rule}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          ) : (
            <ul className="text-sm text-blue-700 space-y-2">
              {guidelines.map((guideline, index) => (
                <li key={index} className="flex items-start gap-2">
                  <CheckCircle2 className="h-3 w-3 mt-0.5 text-green-600 flex-shrink-0" />
                  <span>{guideline}</span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    );
  };

  const renderLegalNotices = () => {
    const legalNotices = {
      linkedin: {
        title: "LinkedIn Legal Notice",
        content: "LinkedIn scraping must comply with their User Agreement and robots.txt. Only public information should be collected, and excessive automated activity may result in account restrictions.",
        link: "https://www.linkedin.com/legal/user-agreement"
      },
      google: {
        title: "Google API Terms",
        content: "Usage of Google Custom Search API is subject to Google's API Terms of Service and usage limits. Exceeding quotas may result in additional charges.",
        link: "https://developers.google.com/terms"
      },
      bing: {
        title: "Microsoft API Terms",
        content: "Bing Web Search API usage is governed by Microsoft Azure terms and conditions. Monitor your usage to avoid unexpected charges.",
        link: "https://azure.microsoft.com/en-us/support/legal/"
      },
      yahoo: {
        title: "Web Scraping Notice",
        content: "Yahoo search scraping must respect robots.txt directives and implement appropriate rate limiting to avoid being blocked.",
        link: null
      }
    };

    const notice = legalNotices[platform];
    if (!notice || platform === "all") return null;

    return (
      <Alert className="border-gray-200 bg-gray-50">
        <Info className="h-4 w-4" />
        <AlertDescription>
          <div className="space-y-2">
            <div className="font-medium">{notice.title}</div>
            <div className="text-sm text-muted-foreground">{notice.content}</div>
            {notice.link && (
              <Button size="sm" variant="outline" asChild>
                <a href={notice.link} target="_blank" rel="noopener noreferrer">
                  Read Terms <ExternalLink className="h-3 w-3 ml-1" />
                </a>
              </Button>
            )}
          </div>
        </AlertDescription>
      </Alert>
    );
  };

  const renderGeneralWarnings = () => {
    if (platform !== "all") return null;

    return (
      <div className="space-y-4">
        <Alert className="border-yellow-200 bg-yellow-50">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <div className="space-y-2">
              <div className="font-medium">Important Usage Reminders</div>
              <ul className="text-sm space-y-1">
                <li>• Monitor your daily and monthly limits across all platforms</li>
                <li>• Use data collected for legitimate business purposes only</li>
                <li>• Respect recipient privacy and provide opt-out options</li>
                <li>• Never use prospect data for spam or unsolicited marketing</li>
                <li>• Keep API keys secure and never share account access</li>
              </ul>
            </div>
          </AlertDescription>
        </Alert>

        <Alert className="border-green-200 bg-green-50">
          <CheckCircle2 className="h-4 w-4" />
          <AlertDescription>
            <div className="space-y-2">
              <div className="font-medium">Best Practices for Success</div>
              <ul className="text-sm space-y-1">
                <li>• Start with small, targeted searches to test effectiveness</li>
                <li>• Quality over quantity - focus on well-qualified prospects</li>
                <li>• Personalize outreach based on collected profile information</li>
                <li>• Track conversion rates to optimize your search strategies</li>
                <li>• Regular compliance reviews to ensure ongoing adherence</li>
              </ul>
            </div>
          </AlertDescription>
        </Alert>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {renderPlatformWarning()}
      {renderComplianceGuidelines()}
      {renderLegalNotices()}
      {renderGeneralWarnings()}
    </div>
  );
}
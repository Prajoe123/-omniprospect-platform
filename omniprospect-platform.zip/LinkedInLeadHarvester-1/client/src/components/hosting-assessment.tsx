import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, AlertTriangle, Info, Cpu, HardDrive, Wifi, Database } from "lucide-react";

export default function HostingAssessment() {
  return (
    <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-100 mb-8">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-2">Cloud Hosting Assessment</h2>
            <p className="text-muted-foreground">
              Evaluation for your OmniProspect (LinkedInLeadHarvester) deployment
            </p>
          </div>
          <div className="glassmorphism rounded-xl p-4">
            <div className="text-2xl font-bold text-primary">$3.00/mo</div>
            <div className="text-sm text-muted-foreground">Current Plan</div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Current Specifications</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-surface rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <Cpu className="h-5 w-5 text-primary" />
                  <span>CPU Cores</span>
                </div>
                <span className="font-medium">1 Core</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-surface rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <Database className="h-5 w-5 text-primary" />
                  <span>Memory</span>
                </div>
                <span className="font-medium">2GB RAM</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-surface rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <HardDrive className="h-5 w-5 text-primary" />
                  <span>Storage</span>
                </div>
                <span className="font-medium">40GB SSD</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-surface rounded-lg border border-border">
                <div className="flex items-center gap-3">
                  <Wifi className="h-5 w-5 text-primary" />
                  <span>Bandwidth</span>
                </div>
                <span className="font-medium">2TB Transfer @ 10Gbps</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-foreground">Assessment Results</h3>
            <div className="space-y-3">
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle2 className="h-5 w-5 text-success" />
                  <span className="font-medium text-green-800">Development Environment ✓</span>
                </div>
                <p className="text-sm text-green-700">
                  Adequate for development, testing, and small-scale deployments
                </p>
              </div>

              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="h-5 w-5 text-warning" />
                  <span className="font-medium text-yellow-800">Production Considerations</span>
                </div>
                <p className="text-sm text-yellow-700">
                  May need scaling for high concurrency (&gt;50 users) or heavy automation workloads
                </p>
              </div>

              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Info className="h-5 w-5 text-primary" />
                  <span className="font-medium text-blue-800">Recommended Upgrades</span>
                </div>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• 4GB RAM for PostgreSQL + Gunicorn workers</li>
                  <li>• 2 CPU cores for concurrent scraping tasks</li>
                  <li>• Consider Redis for session/cache management</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

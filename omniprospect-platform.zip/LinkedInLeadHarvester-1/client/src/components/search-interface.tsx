import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Search, Plus, MapPin, Building, Briefcase, Users, CheckCircle2, AlertCircle, Clock, Shield, Zap, Target, BookOpen } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SearchResult {
  id: number;
  results: Array<{
    source: string;
    results: any[];
    totalResults: number;
    searchTime: number;
  }>;
  errors: Array<{
    source: string;
    error: string;
  }>;
  query: string;
}

export default function SearchInterface() {
  const [query, setQuery] = useState("");
  const [source, setSource] = useState("all");
  const [searchResults, setSearchResults] = useState<SearchResult | null>(null);
  const [advancedMode, setAdvancedMode] = useState(false);
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(["google", "bing", "linkedin"]);
  const [operators, setOperators] = useState({
    site: "",
    filetype: "",
    intitle: "",
    inurl: "",
  });
  const [booleanOperator, setBooleanOperator] = useState("AND");
  const [booleanTerms, setBooleanTerms] = useState<string[]>(["", ""]);
  const { toast } = useToast();

  const { data: history, isLoading: historyLoading } = useQuery({
    queryKey: ["/api/search/history"],
  });

  const { data: tutorialsData } = useQuery({
    queryKey: ["/api/search/tutorials"]
  });

  const searchMutation = useMutation({
    mutationFn: async (searchData: { query: string; source: string; limit?: number }) => {
      const response = await apiRequest("POST", "/api/search", searchData);
      return response.json();
    },
    onSuccess: (data) => {
      setSearchResults(data);
      if (data.errors?.length > 0) {
        toast({
          title: "Search completed with warnings",
          description: `${data.errors.length} source(s) failed. Check results for details.`,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Search completed successfully",
          description: `Found results from ${data.totalSources} source(s)`,
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Search failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const advancedSearchMutation = useMutation({
    mutationFn: async (searchData: any) => {
      const response = await apiRequest("POST", "/api/search/advanced", searchData);
      return await response.json();
    },
    onSuccess: (data) => {
      setSearchResults({
        id: data.id,
        query: data.query,
        results: data.results.map((platformResult: any) => ({
          source: platformResult.platform,
          results: platformResult.results,
          totalResults: platformResult.totalResults,
          searchTime: platformResult.searchTime
        })),
        errors: []
      });
      toast({
        title: "Advanced Search Completed",
        description: `Found ${data.comparison.totalResults} results across ${data.results.length} platforms`
      });
    },
    onError: (error) => {
      toast({
        title: "Advanced Search Failed",
        description: error.message || "An error occurred during advanced search",
        variant: "destructive"
      });
    }
  });

  const booleanSearchMutation = useMutation({
    mutationFn: async (searchData: any) => {
      const response = await apiRequest("POST", "/api/search/boolean", searchData);
      return await response.json();
    },
    onSuccess: (data) => {
      setSearchResults({
        id: Date.now(),
        query: data.query,
        results: [{
          source: data.platform,
          results: data.results.results,
          totalResults: data.results.totalResults,
          searchTime: data.results.searchTime
        }],
        errors: []
      });
      toast({
        title: "Boolean Search Completed",
        description: `Executed "${data.query}" with ${data.operator} operator`
      });
    },
    onError: (error) => {
      toast({
        title: "Boolean Search Failed",
        description: error.message || "An error occurred during boolean search",
        variant: "destructive"
      });
    }
  });

  const handleSearch = () => {
    if (!query.trim()) {
      toast({
        title: "Invalid search",
        description: "Please enter a search query",
        variant: "destructive",
      });
      return;
    }

    if (advancedMode) {
      handleAdvancedSearch();
    } else {
      searchMutation.mutate({
        query: query.trim(),
        source,
        limit: 10,
      });
    }
  };

  const handleAdvancedSearch = () => {
    const searchData = {
      query,
      platforms: selectedPlatforms,
      operators: Object.fromEntries(
        Object.entries(operators).filter(([_, value]) => value.trim() !== "")
      ),
      limit: 5
    };

    advancedSearchMutation.mutate(searchData);
  };

  const handleBooleanSearch = () => {
    if (!booleanTerms.every(term => term.trim())) {
      toast({
        title: "Terms Required",
        description: "Please fill in all search terms",
        variant: "destructive"
      });
      return;
    }

    booleanSearchMutation.mutate({
      query: "",
      operator: booleanOperator,
      terms: booleanTerms.filter(term => term.trim()),
      platform: "google"
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "connected":
        return "text-success";
      case "setup_required":
        return "text-warning";
      case "error":
        return "text-error";
      default:
        return "text-muted-foreground";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "connected":
        return <CheckCircle2 className="h-4 w-4" />;
      case "setup_required":
        return <Clock className="h-4 w-4" />;
      case "error":
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <AlertCircle className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Compliance Warning */}
      <Alert className="border-blue-200 bg-blue-50">
        <Shield className="h-4 w-4" />
        <AlertDescription>
          <div className="flex justify-between items-start">
            <div>
              <div className="font-medium mb-1">Compliance Reminder</div>
              <div className="text-sm">Stay within daily limits: LinkedIn (100 profiles), Google (100 queries), Bing (33 queries/day). Only collect public information.</div>
            </div>
            <Button size="sm" variant="outline">
              View Limits
            </Button>
          </div>
        </AlertDescription>
      </Alert>

      {/* Search APIs Status */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl font-bold">Enhanced Search Discovery</CardTitle>
              <p className="text-muted-foreground">
                Integrated Google, Bing, Yahoo search engines and LinkedIn for compliant lead discovery
              </p>
            </div>
            <Button onClick={() => setSearchResults(null)}>
              <Plus className="w-4 h-4 mr-2" />
              New Search
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
            <div className="p-4 border border-border rounded-xl hover:border-primary transition-colors">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Search className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Google Custom Search</h3>
                  <p className="text-sm text-muted-foreground">Compliant web search API</p>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">API Status:</span>
                  <div className={`flex items-center gap-1 font-medium ${getStatusColor("connected")}`}>
                    {getStatusIcon("connected")}
                    <span>Connected</span>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Daily Limit:</span>
                  <span className="text-foreground">100 queries (free)</span>
                </div>
              </div>
            </div>

            <div className="p-4 border border-border rounded-xl hover:border-primary transition-colors">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <Search className="h-5 w-5 text-indigo-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Bing Web Search</h3>
                  <p className="text-sm text-muted-foreground">Microsoft Azure API</p>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">API Status:</span>
                  <div className={`flex items-center gap-1 font-medium ${getStatusColor("connected")}`}>
                    {getStatusIcon("connected")}
                    <span>Connected</span>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Daily Limit:</span>
                  <span className="text-foreground">1,000 queries</span>
                </div>
              </div>
            </div>

            <div className="p-4 border border-border rounded-xl hover:border-primary transition-colors">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Search className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Yahoo Search</h3>
                  <p className="text-sm text-muted-foreground">Web scraping (robots.txt compliant)</p>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">API Status:</span>
                  <div className={`flex items-center gap-1 font-medium ${getStatusColor("setup_required")}`}>
                    {getStatusIcon("setup_required")}
                    <span>Setup Required</span>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Rate Limit:</span>
                  <span className="text-foreground">Respectful scraping</span>
                </div>
              </div>
            </div>

            <div className="p-4 border border-border rounded-xl hover:border-primary transition-colors">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Search className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">LinkedIn Search</h3>
                  <p className="text-sm text-muted-foreground">Public profiles (compliance-focused)</p>
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status:</span>
                  <div className={`flex items-center gap-1 font-medium ${getStatusColor("connected")}`}>
                    {getStatusIcon("connected")}
                    <span>Connected</span>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Daily Limit:</span>
                  <span className="text-foreground">&lt;100 profiles (free)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Enhanced Search Interface with Advanced Features */}
          <div className="bg-background-secondary rounded-xl p-6">
            <div className="mb-6">
              <div className="flex items-center gap-4 mb-4">
                <Button
                  variant={!advancedMode ? "default" : "outline"}
                  size="sm"
                  onClick={() => setAdvancedMode(false)}
                >
                  <Search className="w-4 h-4 mr-2" />
                  Quick Search
                </Button>
                <Button
                  variant={advancedMode ? "default" : "outline"}
                  size="sm"
                  onClick={() => setAdvancedMode(true)}
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Advanced Multi-Platform
                </Button>
              </div>

              {!advancedMode ? (
                // Quick Search Mode
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <div className="flex-1 relative">
                      <Input
                        type="text"
                        placeholder="Search for prospects, companies, or keywords..."
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                        className="pl-12"
                      />
                      <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    </div>
                    <Select value={source} onValueChange={setSource}>
                      <SelectTrigger className="w-48">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Sources</SelectItem>
                        <SelectItem value="google">Google Custom Search</SelectItem>
                        <SelectItem value="bing">Bing Web Search</SelectItem>
                        <SelectItem value="yahoo">Yahoo Search</SelectItem>
                        <SelectItem value="linkedin">LinkedIn Search</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button onClick={handleSearch} disabled={searchMutation.isPending}>
                      {searchMutation.isPending ? "Searching..." : "Search"}
                    </Button>
                  </div>

                  {/* Quick Filters */}
                  <div className="flex flex-wrap gap-3">
                    <Button variant="outline" size="sm">
                      <Building className="w-4 h-4 mr-1" />
                      Company Size
                    </Button>
                    <Button variant="outline" size="sm">
                      <MapPin className="w-4 h-4 mr-1" />
                      Location
                    </Button>
                    <Button variant="outline" size="sm">
                      <Briefcase className="w-4 h-4 mr-1" />
                      Industry
                    </Button>
                    <Button variant="outline" size="sm">
                      <Users className="w-4 h-4 mr-1" />
                      Job Title
                    </Button>
                  </div>
                </div>
              ) : (
                // Advanced Search Mode
                <div className="space-y-6">
                  <div className="space-y-4">
                    <Label htmlFor="advanced-query">Advanced Search Query</Label>
                    <div className="relative">
                      <Input
                        id="advanced-query"
                        type="text"
                        placeholder="Enter your search query (supports boolean operators like AND, OR, NOT)"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        className="pl-12"
                      />
                      <Target className="absolute left-4 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Platform Selection */}
                    <div className="space-y-3">
                      <Label>Search Platforms</Label>
                      <div className="grid grid-cols-2 gap-3">
                        {["google", "bing", "duckduckgo", "linkedin"].map((platform) => (
                          <div key={platform} className="flex items-center space-x-2">
                            <Checkbox
                              id={platform}
                              checked={selectedPlatforms.includes(platform)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setSelectedPlatforms([...selectedPlatforms, platform]);
                                } else {
                                  setSelectedPlatforms(selectedPlatforms.filter(p => p !== platform));
                                }
                              }}
                            />
                            <Label htmlFor={platform} className="capitalize text-sm">
                              {platform === "duckduckgo" ? "DuckDuckGo" : platform}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Advanced Operators */}
                    <div className="space-y-3">
                      <Label>Search Operators</Label>
                      <div className="space-y-2">
                        <Input
                          placeholder="site: (e.g., linkedin.com)"
                          value={operators.site}
                          onChange={(e) => setOperators({...operators, site: e.target.value})}
                        />
                        <Input
                          placeholder="filetype: (e.g., pdf)"
                          value={operators.filetype}
                          onChange={(e) => setOperators({...operators, filetype: e.target.value})}
                        />
                        <Input
                          placeholder="intitle: (e.g., engineer)"
                          value={operators.intitle}
                          onChange={(e) => setOperators({...operators, intitle: e.target.value})}
                        />
                        <Input
                          placeholder="inurl: (e.g., profile)"
                          value={operators.inurl}
                          onChange={(e) => setOperators({...operators, inurl: e.target.value})}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex items-center gap-4">
                      <Button 
                        onClick={handleSearch} 
                        disabled={advancedSearchMutation.isPending}
                        className="bg-gradient-to-r from-blue-600 to-purple-600"
                      >
                        {advancedSearchMutation.isPending ? "Searching..." : "Search All Platforms"}
                      </Button>
                      
                      {tutorialsData && (
                        <Button variant="outline" size="sm">
                          <BookOpen className="w-4 h-4 mr-2" />
                          View Tutorials ({tutorialsData.totalTutorials})
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search Results */}
      {searchResults && (
        <Card>
          <CardHeader>
            <CardTitle>Search Results for "{searchResults.query}"</CardTitle>
          </CardHeader>
          <CardContent>
            {searchResults.errors?.length > 0 && (
              <Alert variant="destructive" className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  {searchResults.errors.length} source(s) failed: {" "}
                  {searchResults.errors.map(e => `${e.source} (${e.error})`).join(", ")}
                </AlertDescription>
              </Alert>
            )}

            <div className="space-y-6">
              {searchResults.results.map((result, index) => (
                <div key={index} className="border border-border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <Badge variant="outline" className="capitalize">
                      {result.source}
                    </Badge>
                    <div className="text-sm text-muted-foreground">
                      {result.totalResults.toLocaleString()} results in {result.searchTime}s
                    </div>
                  </div>

                  <div className="space-y-3">
                    {result.results.slice(0, 3).map((item: any, itemIndex: number) => (
                      <div key={itemIndex} className="p-3 bg-background-secondary rounded-lg">
                        <h4 className="font-medium text-foreground mb-1">
                          {item.title || item.name || "Result"}
                        </h4>
                        <p className="text-sm text-muted-foreground mb-2">
                          {item.snippet || item.description || "No description available"}
                        </p>
                        {item.link && (
                          <a
                            href={item.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-primary hover:underline"
                          >
                            {item.link}
                          </a>
                        )}
                      </div>
                    ))}
                  </div>

                  {result.results.length > 3 && (
                    <Button variant="ghost" size="sm" className="mt-3">
                      View all {result.results.length} results
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search History */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Searches</CardTitle>
        </CardHeader>
        <CardContent>
          {historyLoading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : history?.length > 0 ? (
            <div className="space-y-3">
              {history.slice(0, 5).map((search: any) => (
                <div
                  key={search.id}
                  className="flex items-center justify-between p-3 border border-border rounded-lg hover:bg-background-secondary transition-colors cursor-pointer"
                  onClick={() => {
                    setQuery(search.query);
                    setSource(search.source);
                  }}
                >
                  <div>
                    <div className="font-medium text-foreground">{search.query}</div>
                    <div className="text-sm text-muted-foreground">
                      {search.source} • {new Date(search.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                  <Badge variant="outline">{search.source}</Badge>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-8">
              No search history yet. Start by performing your first search above.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

import { ReactNode } from "react";

interface StatsCardProps {
  title: string;
  value: string;
  icon: ReactNode;
  gradient: string;
  iconColor: string;
}

export default function StatsCard({ title, value, icon, gradient, iconColor }: StatsCardProps) {
  return (
    <div className={`text-center p-4 bg-gradient-to-br ${gradient} rounded-xl`}>
      <div className={`${iconColor} mb-2 flex justify-center`}>
        {icon}
      </div>
      <div className="text-2xl font-bold text-foreground">{value}</div>
      <div className="text-sm text-muted-foreground">{title}</div>
    </div>
  );
}

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Linkedin, 
  Network,
  Info,
  ExternalLink
} from "lucide-react";

interface ComplianceData {
  linkedin: {
    dailyUsed: number;
    dailyLimit: number;
    accountType: "free" | "premium" | "enterprise";
    lastRequest: string;
    rateLimit: number; // seconds between requests
  };
  google: {
    dailyUsed: number;
    dailyLimit: number;
    monthlyUsed: number;
    monthlyLimit: number;
    apiKeyConfigured: boolean;
  };
  bing: {
    dailyUsed: number;
    dailyLimit: number;
    monthlyUsed: number;
    monthlyLimit: number;
    apiKeyConfigured: boolean;
  };
  yahoo: {
    dailyUsed: number;
    estimatedLimit: number;
    avgRequestTime: number;
    robotsTxtCompliant: boolean;
  };
}

interface ComplianceMonitorProps {
  data: ComplianceData;
  onRefresh: () => void;
}

export default function ComplianceMonitor({ data, onRefresh }: ComplianceMonitorProps) {
  const getUsageColor = (used: number, limit: number) => {
    const percentage = (used / limit) * 100;
    if (percentage >= 90) return "text-red-600";
    if (percentage >= 75) return "text-yellow-600";
    return "text-green-600";
  };

  const getUsageStatus = (used: number, limit: number) => {
    const percentage = (used / limit) * 100;
    if (percentage >= 95) return { status: "critical", color: "bg-red-500" };
    if (percentage >= 85) return { status: "warning", color: "bg-yellow-500" };
    if (percentage >= 70) return { status: "caution", color: "bg-orange-500" };
    return { status: "safe", color: "bg-green-500" };
  };

  const formatTimeUntilReset = () => {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    const msUntilReset = tomorrow.getTime() - now.getTime();
    const hoursUntilReset = Math.floor(msUntilReset / (1000 * 60 * 60));
    const minutesUntilReset = Math.floor((msUntilReset % (1000 * 60 * 60)) / (1000 * 60));
    return `${hoursUntilReset}h ${minutesUntilReset}m`;
  };

  return (
    <div className="space-y-6">
      {/* Compliance Overview Header */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-blue-600" />
              <CardTitle className="text-lg">Compliance Monitor</CardTitle>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-green-700 border-green-200">
                <CheckCircle className="h-3 w-3 mr-1" />
                All Systems Compliant
              </Badge>
              <Button variant="ghost" size="sm" onClick={onRefresh}>
                <Clock className="h-4 w-4 mr-1" />
                Refresh
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Alert className="border-blue-200 bg-blue-50">
            <Info className="h-4 w-4" />
            <AlertDescription>
              Daily limits reset at midnight in your timezone ({formatTimeUntilReset()} remaining). 
              Stay within these limits to maintain compliance with platform terms of service.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* LinkedIn Compliance */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Linkedin className="h-5 w-5 text-blue-600" />
              <CardTitle className="text-base">LinkedIn Usage</CardTitle>
              <Badge variant="outline">
                {data.linkedin.accountType.charAt(0).toUpperCase() + data.linkedin.accountType.slice(1)} Account
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Daily Profile Views</span>
              <span className={getUsageColor(data.linkedin.dailyUsed, data.linkedin.dailyLimit)}>
                {data.linkedin.dailyUsed} / {data.linkedin.dailyLimit}
              </span>
            </div>
            <Progress 
              value={(data.linkedin.dailyUsed / data.linkedin.dailyLimit) * 100} 
              className="h-2"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Rate limit: {data.linkedin.rateLimit}s between requests</span>
              <span>{Math.max(0, data.linkedin.dailyLimit - data.linkedin.dailyUsed)} remaining</span>
            </div>
          </div>

          {data.linkedin.dailyUsed / data.linkedin.dailyLimit >= 0.8 && (
            <Alert className="border-yellow-200 bg-yellow-50">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                You've used {Math.round((data.linkedin.dailyUsed / data.linkedin.dailyLimit) * 100)}% of your daily LinkedIn limit. 
                Consider slowing down or upgrading to a premium account for higher limits.
              </AlertDescription>
            </Alert>
          )}

          <div className="grid grid-cols-2 gap-4 pt-2 border-t">
            <div className="text-center">
              <div className="text-lg font-semibold text-green-600">✓ Compliant</div>
              <div className="text-xs text-muted-foreground">Public data only</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-blue-600">{data.linkedin.rateLimit}s</div>
              <div className="text-xs text-muted-foreground">Request delay</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Google Custom Search */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Network className="h-5 w-5 text-blue-500" />
              <CardTitle className="text-base">Google Custom Search</CardTitle>
              {data.google.apiKeyConfigured ? (
                <Badge variant="outline" className="text-green-700 border-green-200">Connected</Badge>
              ) : (
                <Badge variant="outline" className="text-yellow-700 border-yellow-200">Setup Required</Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {data.google.apiKeyConfigured ? (
            <>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Daily Queries</span>
                  <span className={getUsageColor(data.google.dailyUsed, data.google.dailyLimit)}>
                    {data.google.dailyUsed} / {data.google.dailyLimit}
                  </span>
                </div>
                <Progress 
                  value={(data.google.dailyUsed / data.google.dailyLimit) * 100} 
                  className="h-2"
                />
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Monthly Usage</span>
                  <span className={getUsageColor(data.google.monthlyUsed, data.google.monthlyLimit)}>
                    {data.google.monthlyUsed} / {data.google.monthlyLimit}
                  </span>
                </div>
                <Progress 
                  value={(data.google.monthlyUsed / data.google.monthlyLimit) * 100} 
                  className="h-2"
                />
              </div>

              <div className="grid grid-cols-3 gap-2 pt-2 border-t text-center">
                <div>
                  <div className="text-sm font-semibold text-green-600">Official API</div>
                  <div className="text-xs text-muted-foreground">Fully compliant</div>
                </div>
                <div>
                  <div className="text-sm font-semibold text-blue-600">$5/1K</div>
                  <div className="text-xs text-muted-foreground">After free limit</div>
                </div>
                <div>
                  <div className="text-sm font-semibold text-gray-600">No limits</div>
                  <div className="text-xs text-muted-foreground">Rate limiting</div>
                </div>
              </div>
            </>
          ) : (
            <Alert className="border-blue-200 bg-blue-50">
              <Info className="h-4 w-4" />
              <AlertDescription className="flex justify-between items-center">
                <span>Configure Google API for 100 free daily searches</span>
                <Button size="sm" variant="outline">
                  Setup Guide <ExternalLink className="h-3 w-3 ml-1" />
                </Button>
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Bing Web Search */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Network className="h-5 w-5 text-indigo-600" />
              <CardTitle className="text-base">Bing Web Search</CardTitle>
              {data.bing.apiKeyConfigured ? (
                <Badge variant="outline" className="text-green-700 border-green-200">Connected</Badge>
              ) : (
                <Badge variant="outline" className="text-yellow-700 border-yellow-200">Setup Required</Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {data.bing.apiKeyConfigured ? (
            <>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Monthly Queries</span>
                  <span className={getUsageColor(data.bing.monthlyUsed, data.bing.monthlyLimit)}>
                    {data.bing.monthlyUsed} / {data.bing.monthlyLimit}
                  </span>
                </div>
                <Progress 
                  value={(data.bing.monthlyUsed / data.bing.monthlyLimit) * 100} 
                  className="h-2"
                />
                <div className="text-xs text-muted-foreground text-right">
                  Daily equivalent: ~{Math.round(data.bing.monthlyLimit / 30)} queries/day
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 pt-2 border-t text-center">
                <div>
                  <div className="text-sm font-semibold text-green-600">Official API</div>
                  <div className="text-xs text-muted-foreground">Microsoft Azure</div>
                </div>
                <div>
                  <div className="text-sm font-semibold text-blue-600">1K/month</div>
                  <div className="text-xs text-muted-foreground">Free tier</div>
                </div>
                <div>
                  <div className="text-sm font-semibold text-gray-600">Scalable</div>
                  <div className="text-xs text-muted-foreground">Paid tiers</div>
                </div>
              </div>
            </>
          ) : (
            <Alert className="border-blue-200 bg-blue-50">
              <Info className="h-4 w-4" />
              <AlertDescription className="flex justify-between items-center">
                <span>Configure Bing API for 1,000 free monthly searches</span>
                <Button size="sm" variant="outline">
                  Setup Guide <ExternalLink className="h-3 w-3 ml-1" />
                </Button>
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Yahoo Search */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Network className="h-5 w-5 text-purple-600" />
              <CardTitle className="text-base">Yahoo Search</CardTitle>
              <Badge variant="outline" className="text-green-700 border-green-200">
                {data.yahoo.robotsTxtCompliant ? "Compliant" : "Setup Required"}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Daily Requests</span>
              <span className={getUsageColor(data.yahoo.dailyUsed, data.yahoo.estimatedLimit)}>
                {data.yahoo.dailyUsed} / ~{data.yahoo.estimatedLimit}
              </span>
            </div>
            <Progress 
              value={(data.yahoo.dailyUsed / data.yahoo.estimatedLimit) * 100} 
              className="h-2"
            />
            <div className="text-xs text-muted-foreground text-right">
              Rate limited to 1-2 requests/second
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 pt-2 border-t text-center">
            <div>
              <div className="text-sm font-semibold text-green-600">Web Scraping</div>
              <div className="text-xs text-muted-foreground">robots.txt compliant</div>
            </div>
            <div>
              <div className="text-sm font-semibold text-blue-600">{data.yahoo.avgRequestTime}ms</div>
              <div className="text-xs text-muted-foreground">Avg response</div>
            </div>
            <div>
              <div className="text-sm font-semibold text-gray-600">No API cost</div>
              <div className="text-xs text-muted-foreground">Free to use</div>
            </div>
          </div>

          {!data.yahoo.robotsTxtCompliant && (
            <Alert className="border-yellow-200 bg-yellow-50">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Yahoo scraping requires robots.txt compliance verification. Contact support if issues persist.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Compliance Tips */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Compliance Best Practices
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium text-sm">✅ Do's</h4>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Stay within daily platform limits</li>
                <li>• Use data for legitimate business purposes</li>
                <li>• Respect robots.txt and terms of service</li>
                <li>• Maintain request delays between searches</li>
                <li>• Monitor usage through this dashboard</li>
              </ul>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-sm">❌ Don'ts</h4>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Exceed platform rate limits</li>
                <li>• Scrape private or personal data</li>
                <li>• Use data for spam or harassment</li>
                <li>• Ignore platform warnings or blocks</li>
                <li>• Share API keys or account access</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, ArrowRight, Linkedin, Bot, Search, Mail } from "lucide-react";

export default function WorkflowBuilder() {
  return (
    <Card className="mb-8">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg font-semibold">Visual Workflow Builder</CardTitle>
            <p className="text-muted-foreground">Drag-and-drop automation with 15+ workflow nodes</p>
          </div>
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Create Workflow
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {/* Workflow Canvas Preview */}
        <div className="bg-background-secondary rounded-xl p-6 h-64 relative overflow-hidden">
          <div className="absolute inset-0 bg-dot-pattern opacity-20"></div>

          {/* Sample Workflow Nodes */}
          <div className="relative z-10 flex items-center justify-center space-x-8">
            <div className="bg-surface border-2 border-primary rounded-lg p-4 shadow-sm">
              <Linkedin className="h-8 w-8 text-blue-600 mb-2 mx-auto" />
              <div className="text-sm font-medium text-center">
                LinkedIn
                <br />
                Search
              </div>
            </div>

            <ArrowRight className="h-6 w-6 text-muted-foreground" />

            <div className="bg-surface border-2 border-border rounded-lg p-4 shadow-sm">
              <Bot className="h-8 w-8 text-purple-600 mb-2 mx-auto" />
              <div className="text-sm font-medium text-center">
                AI
                <br />
                Enhancement
              </div>
            </div>

            <ArrowRight className="h-6 w-6 text-muted-foreground" />

            <div className="bg-surface border-2 border-border rounded-lg p-4 shadow-sm">
              <Search className="h-8 w-8 text-green-600 mb-2 mx-auto" />
              <div className="text-sm font-medium text-center">
                Search
                <br />
                Discovery
              </div>
            </div>

            <ArrowRight className="h-6 w-6 text-muted-foreground" />

            <div className="bg-surface border-2 border-border rounded-lg p-4 shadow-sm">
              <Mail className="h-8 w-8 text-orange-600 mb-2 mx-auto" />
              <div className="text-sm font-medium text-center">
                Email
                <br />
                Campaign
              </div>
            </div>
          </div>

          <div className="absolute bottom-4 left-4 text-xs text-muted-foreground">
            Sample: LinkedIn → AI Enhancement → Search Discovery → Email Campaign
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

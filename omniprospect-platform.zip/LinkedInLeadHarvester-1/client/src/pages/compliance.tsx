import ComplianceDashboard from "@/components/compliance-dashboard";

export default function Compliance() {
  return (
    <div className="container mx-auto p-6">
      <ComplianceDashboard />
    </div>
  );
}
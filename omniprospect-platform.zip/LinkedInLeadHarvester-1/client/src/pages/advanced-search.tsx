import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Search, 
  Settings, 
  Download, 
  BookOpen, 
  Target, 
  Filter, 
  Zap,
  Globe,
  FileText,
  BarChart3,
  Clock,
  Save
} from "lucide-react";

interface SearchResult {
  platform: string;
  results: any[];
  totalResults: number;
  searchTime: number;
  operators: string[];
}

interface AggregatedResults {
  id: number;
  query: string;
  platforms: string[];
  results: SearchResult[];
  comparison: {
    totalResults: number;
    averageSearchTime: number;
    platformCoverage: Array<{
      platform: string;
      results: number;
      searchTime: number;
      operators: string[];
    }>;
  };
  exportData?: any;
  saved: boolean;
}

export default function AdvancedSearchPage() {
  const [query, setQuery] = useState("");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(["google", "bing"]);
  const [operators, setOperators] = useState({
    site: "",
    filetype: "",
    intitle: "",
    inurl: "",
  });
  const [exportFormat, setExportFormat] = useState<string>("none");
  const [saveQuery, setSaveQuery] = useState(false);
  const [queryName, setQueryName] = useState("");
  const [booleanQuery, setBooleanQuery] = useState("");
  const [booleanOperator, setBooleanOperator] = useState("AND");
  const [booleanTerms, setBooleanTerms] = useState<string[]>(["", ""]);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch tutorials
  const { data: tutorialsData } = useQuery({
    queryKey: ["/api/search/tutorials"]
  });

  // Advanced search mutation
  const advancedSearchMutation = useMutation({
    mutationFn: async (searchData: any) => {
      const response = await apiRequest("POST", "/api/search/advanced", searchData);
      return await response.json();
    },
    onSuccess: (data: AggregatedResults) => {
      toast({
        title: "Search Completed",
        description: `Found ${data.comparison.totalResults} results across ${data.results.length} platforms`
      });
      setResults(data);
    },
    onError: (error: any) => {
      toast({
        title: "Search Failed",
        description: error.message || "An error occurred during search",
        variant: "destructive"
      });
    }
  });

  // Boolean search mutation
  const booleanSearchMutation = useMutation({
    mutationFn: async (searchData: any) => {
      const response = await apiRequest("POST", "/api/search/boolean", searchData);
      return await response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Boolean Search Completed",
        description: `Executed "${data.query}" with ${data.operator} operator`
      });
      setBooleanResults(data);
    }
  });

  const [results, setResults] = useState<AggregatedResults | null>(null);
  const [booleanResults, setBooleanResults] = useState<any>(null);

  const handleAdvancedSearch = () => {
    if (!query.trim()) {
      toast({
        title: "Query Required",
        description: "Please enter a search query",
        variant: "destructive"
      });
      return;
    }

    const searchData = {
      query,
      platforms: selectedPlatforms,
      operators: Object.fromEntries(
        Object.entries(operators).filter(([_, value]) => value.trim() !== "")
      ),
      exportFormat: exportFormat && exportFormat !== "none" ? exportFormat : undefined,
      saveQuery,
      queryName: queryName || undefined,
      limit: 5
    };

    advancedSearchMutation.mutate(searchData);
  };

  const handleBooleanSearch = () => {
    if (!booleanTerms.every(term => term.trim())) {
      toast({
        title: "Terms Required",
        description: "Please fill in all search terms",
        variant: "destructive"
      });
      return;
    }

    booleanSearchMutation.mutate({
      query: booleanQuery,
      operator: booleanOperator,
      terms: booleanTerms.filter(term => term.trim()),
      platform: "google"
    });
  };

  const handleExport = async (resultId: number, format: string) => {
    try {
      const response = await fetch(`/api/search/${resultId}/export/${format}`);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `search-results-${resultId}.${format}`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Export Successful",
        description: `Results exported as ${format.toUpperCase()}`
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Could not export search results",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Search className="h-8 w-8 text-blue-600" />
        <div>
          <h1 className="text-3xl font-bold">Advanced Multi-Platform Search</h1>
          <p className="text-gray-600">Search across Google, Bing, DuckDuckGo, and Yandex with advanced operators</p>
        </div>
      </div>

      <Tabs defaultValue="advanced" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="advanced" className="flex items-center gap-2">
            <Target className="h-4 w-4" />
            Advanced Search
          </TabsTrigger>
          <TabsTrigger value="boolean" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Boolean Search
          </TabsTrigger>
          <TabsTrigger value="tutorials" className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            Tutorials
          </TabsTrigger>
          <TabsTrigger value="results" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Results
          </TabsTrigger>
        </TabsList>

        <TabsContent value="advanced" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Advanced Search Configuration
              </CardTitle>
              <CardDescription>
                Use advanced operators and multi-platform search for comprehensive results
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="query">Search Query</Label>
                <Textarea
                  id="query"
                  placeholder="Enter your search query (e.g., software engineer startup)"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="min-h-[80px]"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Search Platforms</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {["google", "bing", "duckduckgo", "yandex"].map((platform) => (
                      <div key={platform} className="flex items-center space-x-2">
                        <Checkbox
                          id={platform}
                          checked={selectedPlatforms.includes(platform)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setSelectedPlatforms([...selectedPlatforms, platform]);
                            } else {
                              setSelectedPlatforms(selectedPlatforms.filter(p => p !== platform));
                            }
                          }}
                        />
                        <Label htmlFor={platform} className="capitalize">
                          {platform === "duckduckgo" ? "DuckDuckGo" : platform}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Advanced Operators</Label>
                  <div className="space-y-2">
                    <Input
                      placeholder="site: (e.g., linkedin.com)"
                      value={operators.site}
                      onChange={(e) => setOperators({...operators, site: e.target.value})}
                    />
                    <Input
                      placeholder="filetype: (e.g., pdf)"
                      value={operators.filetype}
                      onChange={(e) => setOperators({...operators, filetype: e.target.value})}
                    />
                    <Input
                      placeholder="intitle: (e.g., engineer)"
                      value={operators.intitle}
                      onChange={(e) => setOperators({...operators, intitle: e.target.value})}
                    />
                    <Input
                      placeholder="inurl: (e.g., profile)"
                      value={operators.inurl}
                      onChange={(e) => setOperators({...operators, inurl: e.target.value})}
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="exportFormat">Export Format (Optional)</Label>
                  <Select value={exportFormat} onValueChange={setExportFormat}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No Export</SelectItem>
                      <SelectItem value="json">JSON</SelectItem>
                      <SelectItem value="csv">CSV</SelectItem>
                      <SelectItem value="pdf">PDF Data</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="saveQuery"
                      checked={saveQuery}
                      onCheckedChange={setSaveQuery}
                    />
                    <Label htmlFor="saveQuery">Save Query</Label>
                  </div>
                  {saveQuery && (
                    <Input
                      placeholder="Query name"
                      value={queryName}
                      onChange={(e) => setQueryName(e.target.value)}
                    />
                  )}
                </div>

                <div className="flex items-end">
                  <Button 
                    onClick={handleAdvancedSearch}
                    disabled={advancedSearchMutation.isPending}
                    className="w-full"
                  >
                    {advancedSearchMutation.isPending ? "Searching..." : "Search All Platforms"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="boolean" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Boolean Search Operators
              </CardTitle>
              <CardDescription>
                Use AND, OR, NOT, and proximity operators for precise searches
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="operator">Boolean Operator</Label>
                  <Select value={booleanOperator} onValueChange={setBooleanOperator}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="AND">AND (all terms must appear)</SelectItem>
                      <SelectItem value="OR">OR (any term can appear)</SelectItem>
                      <SelectItem value="NOT">NOT (exclude terms)</SelectItem>
                      <SelectItem value="NEAR">NEAR (terms close together)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Search Terms</Label>
                  <div className="space-y-2">
                    {booleanTerms.map((term, index) => (
                      <Input
                        key={index}
                        placeholder={`Term ${index + 1}`}
                        value={term}
                        onChange={(e) => {
                          const newTerms = [...booleanTerms];
                          newTerms[index] = e.target.value;
                          setBooleanTerms(newTerms);
                        }}
                      />
                    ))}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setBooleanTerms([...booleanTerms, ""])}
                    >
                      Add Term
                    </Button>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="previewQuery">Generated Query Preview</Label>
                <div className="p-3 bg-gray-50 rounded-md">
                  <code className="text-sm">
                    {booleanOperator === "AND" 
                      ? booleanTerms.filter(t => t.trim()).join(" AND ")
                      : booleanOperator === "OR"
                      ? booleanTerms.filter(t => t.trim()).join(" OR ")
                      : booleanOperator === "NOT"
                      ? `${booleanTerms[0]} NOT ${booleanTerms.slice(1).filter(t => t.trim()).join(" NOT ")}`
                      : booleanOperator === "NEAR"
                      ? `${booleanTerms[0]} NEAR:5 ${booleanTerms[1]}`
                      : booleanTerms.join(" ")
                    }
                  </code>
                </div>
              </div>

              <Button 
                onClick={handleBooleanSearch}
                disabled={booleanSearchMutation.isPending}
                className="w-full"
              >
                {booleanSearchMutation.isPending ? "Searching..." : "Execute Boolean Search"}
              </Button>

              {booleanResults && (
                <Card className="mt-4">
                  <CardHeader>
                    <CardTitle className="text-lg">Boolean Search Results</CardTitle>
                    <CardDescription>
                      Query: <code>{booleanResults.query}</code> | 
                      Operator: <Badge variant="secondary">{booleanResults.operator}</Badge>
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {booleanResults.results.results?.map((result: any, index: number) => (
                        <div key={index} className="border-l-4 border-blue-500 pl-4">
                          <h4 className="font-medium">{result.title}</h4>
                          <p className="text-sm text-gray-600 mt-1">{result.snippet}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge variant="outline">{result.displayLink}</Badge>
                            {result.operators?.map((op: string) => (
                              <Badge key={op} variant="secondary" className="text-xs">
                                {op}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tutorials" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Search Tutorials & Examples
              </CardTitle>
              <CardDescription>
                Learn advanced search techniques with practical examples
              </CardDescription>
            </CardHeader>
            <CardContent>
              {tutorialsData && (
                <div className="grid gap-4">
                  {tutorialsData.tutorials?.map((tutorial: any) => (
                    <Card key={tutorial.id} className="border border-gray-200">
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">{tutorial.title}</CardTitle>
                          <div className="flex gap-2">
                            <Badge variant={tutorial.difficulty === "beginner" ? "default" : tutorial.difficulty === "intermediate" ? "secondary" : "destructive"}>
                              {tutorial.difficulty}
                            </Badge>
                            <Badge variant="outline">{tutorial.category}</Badge>
                          </div>
                        </div>
                        <CardDescription>{tutorial.description}</CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div>
                          <Label className="text-sm font-medium">Example Query:</Label>
                          <div className="mt-1 p-2 bg-gray-50 rounded-md">
                            <code className="text-sm">{tutorial.example}</code>
                          </div>
                        </div>
                        
                        <div>
                          <Label className="text-sm font-medium">Expected Results:</Label>
                          <p className="text-sm text-gray-600 mt-1">{tutorial.expectedResults}</p>
                        </div>

                        {tutorial.tips && tutorial.tips.length > 0 && (
                          <div>
                            <Label className="text-sm font-medium">Tips:</Label>
                            <ul className="text-sm text-gray-600 mt-1 space-y-1">
                              {tutorial.tips.map((tip: string, index: number) => (
                                <li key={index} className="flex items-start gap-2">
                                  <span className="text-blue-500 mt-1.5 h-1 w-1 rounded-full bg-current flex-shrink-0"></span>
                                  {tip}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setQuery(tutorial.searchQuery);
                            // Switch to advanced search tab
                            const advancedTab = document.querySelector('[value="advanced"]') as HTMLButtonElement;
                            advancedTab?.click();
                          }}
                          className="mt-3"
                        >
                          Try This Example
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results" className="space-y-6">
          {results ? (
            <>
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <BarChart3 className="h-5 w-5" />
                      Search Results Overview
                    </span>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleExport(results.id, "json")}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        JSON
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleExport(results.id, "csv")}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        CSV
                      </Button>
                    </div>
                  </CardTitle>
                  <CardDescription>
                    Query: <strong>"{results.query}"</strong> | 
                    Platforms: {results.platforms.join(", ")} | 
                    Total Results: {results.comparison.totalResults}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <Globe className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                      <div className="text-2xl font-bold text-blue-600">{results.platforms.length}</div>
                      <div className="text-sm text-gray-600">Platforms Searched</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <FileText className="h-8 w-8 mx-auto mb-2 text-green-600" />
                      <div className="text-2xl font-bold text-green-600">{results.comparison.totalResults}</div>
                      <div className="text-sm text-gray-600">Total Results</div>
                    </div>
                    <div className="text-center p-4 bg-orange-50 rounded-lg">
                      <Clock className="h-8 w-8 mx-auto mb-2 text-orange-600" />
                      <div className="text-2xl font-bold text-orange-600">{results.comparison.averageSearchTime}ms</div>
                      <div className="text-sm text-gray-600">Average Search Time</div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {results.results.map((platformResult, index) => (
                      <Card key={index} className="border border-gray-200">
                        <CardHeader className="pb-3">
                          <CardTitle className="flex items-center justify-between">
                            <span className="capitalize flex items-center gap-2">
                              <Globe className="h-4 w-4" />
                              {platformResult.platform}
                            </span>
                            <div className="flex gap-2">
                              <Badge variant="secondary">
                                {platformResult.totalResults} results
                              </Badge>
                              <Badge variant="outline">
                                {Math.round(platformResult.searchTime)}ms
                              </Badge>
                            </div>
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            {platformResult.results.slice(0, 3).map((result: any, resultIndex: number) => (
                              <div key={resultIndex} className="border-l-4 border-gray-300 pl-4">
                                <h4 className="font-medium">{result.title || result.name}</h4>
                                <p className="text-sm text-gray-600 mt-1">{result.snippet || result.abstract}</p>
                                <div className="flex items-center gap-2 mt-2">
                                  <Badge variant="outline" className="text-xs">
                                    {result.displayLink || result.displayUrl || result.source || result.host}
                                  </Badge>
                                  {result.operators?.map((op: string) => (
                                    <Badge key={op} variant="secondary" className="text-xs">
                                      {op}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <Search className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-medium mb-2">No Search Results Yet</h3>
                <p className="text-gray-600 mb-4">
                  Run an advanced search to see comprehensive results across multiple platforms
                </p>
                <Button variant="outline" onClick={() => {
                  const advancedTab = document.querySelector('[value="advanced"]') as HTMLButtonElement;
                  advancedTab?.click();
                }}>
                  Start Advanced Search
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
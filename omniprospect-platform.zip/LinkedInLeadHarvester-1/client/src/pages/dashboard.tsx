import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Bell, Network, Search, Plus, Zap } from "lucide-react";
import { Link } from "wouter";
import HostingAssessment from "@/components/hosting-assessment";
import SearchInterface from "@/components/search-interface";
import PlatformOverview from "@/components/platform-overview";
import WorkflowBuilder from "@/components/workflow-builder";
import FeatureShowcase from "@/components/feature-showcase";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("dashboard");

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: platforms, isLoading: platformsLoading } = useQuery({
    queryKey: ["/api/platforms"],
  });

  return (
    <div className="min-h-screen bg-background">


      {/* Navigation Header */}
      <nav className="bg-surface shadow-sm border-b border-border sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
                  <Network className="w-4 h-4 text-white" />
                </div>
                <h1 className="text-xl font-bold text-foreground">OmniProspect</h1>
              </div>
              <div className="hidden md:flex items-center gap-6">
                <button
                  onClick={() => setActiveTab("dashboard")}
                  className={`text-sm font-medium pb-4 border-b-2 transition-all ${
                    activeTab === "dashboard"
                      ? "text-primary border-primary"
                      : "text-muted-foreground border-transparent hover:text-primary hover:border-primary"
                  }`}
                >
                  Dashboard
                </button>
                <button
                  onClick={() => setActiveTab("search")}
                  className={`text-sm font-medium pb-4 border-b-2 transition-all ${
                    activeTab === "search"
                      ? "text-primary border-primary"
                      : "text-muted-foreground border-transparent hover:text-primary hover:border-primary"
                  }`}
                >
                  Search Discovery
                </button>
                <button
                  onClick={() => setActiveTab("workflows")}
                  className={`text-sm font-medium pb-4 border-b-2 transition-all ${
                    activeTab === "workflows"
                      ? "text-primary border-primary"
                      : "text-muted-foreground border-transparent hover:text-primary hover:border-primary"
                  }`}
                >
                  Workflows
                </button>
                <button
                  onClick={() => setActiveTab("analytics")}
                  className={`text-sm font-medium pb-4 border-b-2 transition-all ${
                    activeTab === "analytics"
                      ? "text-primary border-primary"
                      : "text-muted-foreground border-transparent hover:text-primary hover:border-primary"
                  }`}
                >
                  Analytics
                </button>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm">
                <Bell className="h-4 w-4" />
              </Button>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white text-sm font-medium">
                  DU
                </div>
                <span className="hidden sm:block text-sm font-medium text-foreground">
                  Demo User
                </span>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-6">
        {activeTab === "dashboard" && (
          <>
            <PlatformOverview 
              stats={stats} 
              platforms={platforms} 
              isLoading={statsLoading || platformsLoading} 
            />
            <WorkflowBuilder />
            <FeatureShowcase />
          </>
        )}

        {activeTab === "search" && <SearchInterface />}

        {activeTab === "workflows" && (
          <div className="bg-surface rounded-2xl shadow-sm border border-border p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">Workflow Management</h2>
                <p className="text-muted-foreground">Create and manage automation workflows</p>
              </div>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Create Workflow
              </Button>
            </div>
            <WorkflowBuilder />
          </div>
        )}

        {activeTab === "analytics" && (
          <div className="bg-surface rounded-2xl shadow-sm border border-border p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">Analytics & Insights</h2>
                <p className="text-muted-foreground">Track performance and usage metrics</p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="p-4 border border-border rounded-xl">
                <h3 className="font-semibold text-foreground mb-2">API Usage</h3>
                <p className="text-2xl font-bold text-primary">1,247</p>
                <p className="text-sm text-muted-foreground">Total requests this month</p>
              </div>
              <div className="p-4 border border-border rounded-xl">
                <h3 className="font-semibold text-foreground mb-2">Search Queries</h3>
                <p className="text-2xl font-bold text-primary">456</p>
                <p className="text-sm text-muted-foreground">Across all sources</p>
              </div>
              <div className="p-4 border border-border rounded-xl">
                <h3 className="font-semibold text-foreground mb-2">Success Rate</h3>
                <p className="text-2xl font-bold text-success">94.2%</p>
                <p className="text-sm text-muted-foreground">API call success rate</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-card text-card-foreground mt-12 border-t border-border">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Network className="w-4 h-4 text-white" />
                </div>
                <h3 className="text-lg font-bold">OmniProspect</h3>
              </div>
              <p className="text-muted-foreground text-sm">
                Enterprise-grade social media automation platform with 50+ features.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Platform</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">LinkedIn Integration</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">AI Enhancement</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Workflow Builder</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Search Discovery</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Resources</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground transition-colors">API Documentation</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Python SDK</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">CLI Tool</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Tutorials</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Contact</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>Enterprise Support</li>
                <li>API Integration Help</li>
                <li>Deployment Assistance</li>
                <li>Custom Solutions</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-6 text-center text-sm text-muted-foreground">
            <p>&copy; 2025 OmniProspect. Production-ready social media automation platform.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

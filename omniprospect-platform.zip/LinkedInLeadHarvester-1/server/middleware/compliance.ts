import { Request, Response, NextFunction } from "express";

interface RateLimitConfig {
  windowMs: number;
  maxRequests: number;
  platform: string;
}

interface RateLimitStore {
  [key: string]: {
    count: number;
    resetTime: number;
  };
}

class ComplianceMiddleware {
  private rateLimitStore: RateLimitStore = {};

  // Platform-specific rate limits
  private limits: { [platform: string]: RateLimitConfig } = {
    linkedin: {
      windowMs: 24 * 60 * 60 * 1000, // 24 hours
      maxRequests: 100, // 100 profiles per day for free accounts
      platform: "linkedin"
    },
    google: {
      windowMs: 24 * 60 * 60 * 1000, // 24 hours
      maxRequests: 100, // 100 queries per day (free tier)
      platform: "google"
    },
    bing: {
      windowMs: 30 * 24 * 60 * 60 * 1000, // 30 days
      maxRequests: 1000, // 1000 queries per month (free tier)
      platform: "bing"
    },
    yahoo: {
      windowMs: 60 * 1000, // 1 minute
      maxRequests: 2, // 2 requests per minute (rate limiting)
      platform: "yahoo"
    }
  };

  /**
   * Rate limiting middleware for platform compliance
   */
  rateLimit(platform: string) {
    return (req: Request, res: Response, next: NextFunction) => {
      const config = this.limits[platform];
      if (!config) {
        return next();
      }

      const userId = req.session?.userId || req.ip;
      const key = `${platform}:${userId}`;
      const now = Date.now();

      // Clean up expired entries
      this.cleanExpiredEntries();

      // Get or initialize user's rate limit data
      let userLimit = this.rateLimitStore[key];
      if (!userLimit || now > userLimit.resetTime) {
        userLimit = {
          count: 0,
          resetTime: now + config.windowMs
        };
        this.rateLimitStore[key] = userLimit;
      }

      // Check if user has exceeded limit
      if (userLimit.count >= config.maxRequests) {
        const timeUntilReset = userLimit.resetTime - now;
        const resetDate = new Date(userLimit.resetTime);

        return res.status(429).json({
          error: "Rate limit exceeded",
          platform,
          message: `You have exceeded the ${platform} rate limit of ${config.maxRequests} requests. Try again after ${resetDate.toLocaleString()}.`,
          retryAfter: Math.ceil(timeUntilReset / 1000),
          usage: {
            used: userLimit.count,
            limit: config.maxRequests,
            resetTime: userLimit.resetTime
          }
        });
      }

      // Increment counter
      userLimit.count++;
      this.rateLimitStore[key] = userLimit;

      // Add rate limit headers
      res.set({
        'X-RateLimit-Limit': config.maxRequests.toString(),
        'X-RateLimit-Remaining': (config.maxRequests - userLimit.count).toString(),
        'X-RateLimit-Reset': userLimit.resetTime.toString(),
        'X-Platform': platform
      });

      next();
    };
  }

  /**
   * Compliance validation middleware
   */
  validateCompliance() {
    return (req: Request, res: Response, next: NextFunction) => {
      const warnings: string[] = [];

      // Check for suspicious request patterns
      const userAgent = req.get('User-Agent');
      if (!userAgent || userAgent.includes('bot') || userAgent.includes('crawler')) {
        warnings.push("Detected automated user agent. Ensure compliance with platform terms.");
      }

      // Check request frequency
      const userId = req.session?.userId || req.ip;
      const recentRequests = this.getRecentRequestCount(userId);
      if (recentRequests > 10) { // More than 10 requests in last minute
        warnings.push("High request frequency detected. Consider adding delays between requests.");
      }

      // Add compliance warnings to response
      if (warnings.length > 0) {
        res.locals.complianceWarnings = warnings;
      }

      next();
    };
  }

  /**
   * Usage tracking middleware
   */
  trackUsage(platform: string) {
    return (req: Request, res: Response, next: NextFunction) => {
      const userId = req.session?.userId || req.ip;
      const timestamp = new Date().toISOString();

      // Log the usage (in production, this would go to a database)
      console.log(`[USAGE TRACKING] Platform: ${platform}, User: ${userId}, Time: ${timestamp}, IP: ${req.ip}`);

      // Add usage data to request for potential downstream use
      req.usageLog = {
        platform,
        userId,
        timestamp,
        ip: req.ip,
        userAgent: req.get('User-Agent')
      };

      next();
    };
  }

  /**
   * Get current usage statistics for a platform
   */
  getUsageStats(platform: string, userId: string) {
    const config = this.limits[platform];
    if (!config) {
      return null;
    }

    const key = `${platform}:${userId}`;
    const userLimit = this.rateLimitStore[key];
    const now = Date.now();

    if (!userLimit || now > userLimit.resetTime) {
      return {
        used: 0,
        limit: config.maxRequests,
        remaining: config.maxRequests,
        resetTime: now + config.windowMs,
        percentage: 0
      };
    }

    const remaining = Math.max(0, config.maxRequests - userLimit.count);
    const percentage = (userLimit.count / config.maxRequests) * 100;

    return {
      used: userLimit.count,
      limit: config.maxRequests,
      remaining,
      resetTime: userLimit.resetTime,
      percentage: Math.round(percentage)
    };
  }

  /**
   * Get compliance recommendations based on usage
   */
  getComplianceRecommendations(platform: string, userId: string) {
    const stats = this.getUsageStats(platform, userId);
    if (!stats) return [];

    const recommendations: string[] = [];

    if (stats.percentage >= 90) {
      recommendations.push(`You've used ${stats.percentage}% of your ${platform} daily limit. Consider pausing searches.`);
    } else if (stats.percentage >= 75) {
      recommendations.push(`You've used ${stats.percentage}% of your ${platform} limit. Monitor usage carefully.`);
    } else if (stats.percentage >= 50) {
      recommendations.push(`You've used ${stats.percentage}% of your ${platform} limit. Consider spacing out requests.`);
    }

    // Platform-specific recommendations
    switch (platform) {
      case 'linkedin':
        if (stats.percentage >= 80) {
          recommendations.push("Consider upgrading to LinkedIn Premium for higher limits.");
        }
        recommendations.push("Maintain 2-3 second delays between LinkedIn profile requests.");
        break;
      case 'google':
        if (stats.percentage >= 80) {
          recommendations.push("Consider upgrading to Google's paid tier for additional queries.");
        }
        break;
      case 'bing':
        if (stats.percentage >= 80) {
          recommendations.push("Consider upgrading your Azure subscription for higher limits.");
        }
        break;
      case 'yahoo':
        recommendations.push("Yahoo search uses web scraping. Ensure proper delays between requests.");
        break;
    }

    return recommendations;
  }

  /**
   * Clean up expired rate limit entries
   */
  private cleanExpiredEntries() {
    const now = Date.now();
    Object.keys(this.rateLimitStore).forEach(key => {
      if (this.rateLimitStore[key].resetTime < now) {
        delete this.rateLimitStore[key];
      }
    });
  }

  /**
   * Get recent request count for a user
   */
  private getRecentRequestCount(userId: string): number {
    // In a real implementation, this would query a database or cache
    // For now, return a mock count
    return Math.floor(Math.random() * 15);
  }
}

// Export singleton instance
export const complianceMiddleware = new ComplianceMiddleware();

// Export individual middleware functions for easy use
export const linkedinRateLimit = complianceMiddleware.rateLimit('linkedin');
export const googleRateLimit = complianceMiddleware.rateLimit('google');
export const bingRateLimit = complianceMiddleware.rateLimit('bing');
export const yahooRateLimit = complianceMiddleware.rateLimit('yahoo');
export const validateCompliance = complianceMiddleware.validateCompliance();
export const trackLinkedInUsage = complianceMiddleware.trackUsage('linkedin');
export const trackGoogleUsage = complianceMiddleware.trackUsage('google');
export const trackBingUsage = complianceMiddleware.trackUsage('bing');
export const trackYahooUsage = complianceMiddleware.trackUsage('yahoo');